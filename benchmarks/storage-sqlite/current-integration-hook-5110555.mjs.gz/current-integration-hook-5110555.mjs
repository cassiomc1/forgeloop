import { registerHooks } from "node:module";

const currentIntegrationUrl = new URL(
  "/Users/cassio/.codex/worktrees/sqlite-end-to-end/forgeloop/src/integration.js",
  "file:",
).href;
registerHooks({
  resolve(specifier, context, nextResolve) {
    if (specifier === "@cassiomc1/forgeloop/integration") {
      return { url: currentIntegrationUrl, shortCircuit: true };
    }
    return nextResolve(specifier, context);
  },
});
