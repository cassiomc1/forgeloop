import assert from "node:assert/strict";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";

import { buildCanonicalDiagnosisProject } from "/Users/cassio/.codex/worktrees/sqlite-end-to-end/forgeloop/tests/helpers/canonical-diagnosis-fixture.js";
import { appendProtocolEvent, buildProtocolEvent } from "/Users/cassio/.codex/worktrees/sqlite-end-to-end/forgeloop/src/core/events.js";
import { createWorkState } from "/Users/cassio/.codex/worktrees/sqlite-end-to-end/forgeloop/src/core/work-state.js";
import { getPackageRoot as getCurrentPackageRoot } from "/Users/cassio/.codex/worktrees/sqlite-end-to-end/forgeloop/src/core/templates.js";
import { proposeAction } from "/Users/cassio/.codex/worktrees/sqlite-end-to-end/forgeloop/src/core/actions.js";

const oldRoot = process.env.TRACE_PARITY_OLD_ROOT;
const currentRoot = process.env.TRACE_PARITY_CURRENT_ROOT;
if (!oldRoot || !currentRoot) throw new Error("TRACE_PARITY_OLD_ROOT and TRACE_PARITY_CURRENT_ROOT are required");
const [oldTraceModule, currentTraceModule, { getPackageRoot: getOldPackageRoot }] = await Promise.all([
  import(`file://${oldRoot}/src/core/trace.js`),
  import(`file://${currentRoot}/src/core/trace.js`),
  import(`file://${oldRoot}/src/core/templates.js`),
]);
const { buildTaskTrace: buildOldTaskTrace, buildTraceFromSnapshot: buildOldTraceFromSnapshot } = oldTraceModule;
const { buildTaskTrace: buildCurrentTaskTrace, buildTraceFromSnapshot: buildCurrentTraceFromSnapshot } = currentTraceModule;
const currentPackageRoot = getCurrentPackageRoot();
const oldPackageRoot = getOldPackageRoot();

function comparable(trace) {
  const copy = structuredClone(trace);
  copy.snapshot.capturedAt = null;
  return copy;
}

async function compareTraces({ target, taskId, eventsPath = null }) {
  const options = { target, taskId, ...(eventsPath ? { eventsPath } : {}) };
  const oldTrace = await buildOldTaskTrace({ ...options, packageRoot: oldPackageRoot });
  const currentTrace = await buildCurrentTaskTrace({ ...options, packageRoot: currentPackageRoot });
  assert.deepEqual(comparable(currentTrace), comparable(oldTrace));
  return currentTrace;
}

async function nativeControl() {
  const fixture = await buildCanonicalDiagnosisProject({ includePassingCheck: true });
  try {
    const { target, taskId } = fixture;
    await appendProtocolEvent(target, {
      taskId,
      event: "OBSERVATION",
      details: {
        executionId: "exec-parity",
        status: "started",
        exitCode: 0,
        resolution: { resolutionMode: "local" },
        evidenceRefs: ["z-ref", "a-ref"],
        hypotheses: [{ evidenceRefs: ["m-ref"] }],
      },
    }, currentPackageRoot, { taskId });
    await appendProtocolEvent(target, {
      taskId,
      event: "OBSERVATION",
      details: { executionRef: "exec-parity", status: "finished", evidenceRefs: ["a-ref", "b-ref"] },
    }, currentPackageRoot, { taskId });
    await proposeAction(target, {
      packageRoot: currentPackageRoot,
      taskId,
      input: {
        actionId: "action-parity",
        effectClass: "READ_ONLY",
        capability: "filesystem.read",
        target: "origin/main",
        operation: "inspect release branch",
        idempotencyKey: undefined,
        requiredForCompletion: false,
        requirement: "inspection",
        provenance: "HOST_REPORTED",
      },
    });
    const trace = await compareTraces({ target, taskId });
    assert.deepEqual(trace.executions, [{
      executionId: "exec-parity",
      sequence: trace.executions[0].sequence,
      at: trace.executions[0].at,
      status: "started",
      exitCode: 0,
      resolution: { resolutionMode: "local" },
    }]);
    assert.deepEqual(trace.evidence.map(({ ref }) => ref), ["a-ref", "b-ref", "m-ref", "z-ref"]);
    assert.equal(trace.actions.total, 1);
    assert.equal(trace.actions.eventCount, 1);
    return { mode: "native", totalEventCount: trace.events.length, integrityValid: trace.integrity.valid };
  } finally {
    await fixture.cleanup();
  }
}

async function portableControl() {
  const target = await mkdtemp(path.join(os.tmpdir(), "forgeloop-trace-parity-portable-"));
  const taskId = "portable-parity";
  try {
    await mkdir(path.join(target, ".forgeloop"), { recursive: true });
    const state = createWorkState({
      taskId,
      contractFingerprint: "a".repeat(64),
      routeFingerprint: "b".repeat(64),
      repositoryFingerprint: { branch: null, head: null },
      phase: "REVIEWING",
      completedSteps: ["contract", "route", "implementation"],
      pendingSteps: ["completion"],
      verificationCycle: 1,
      checks: [],
    });
    await writeFile(path.join(target, ".forgeloop/work-state.json"), `${JSON.stringify(state)}\n`);

    const events = [];
    let lastHash = null;
    const append = (event, details = {}) => {
      const next = buildProtocolEvent({ taskId, event, details }, { checkpoint: { seq: events.length, lastHash } });
      events.push(next);
      lastHash = next.hash;
    };
    append("TASK_RECEIVED");
    append("CONTRACT_VALIDATED");
    append("ROUTE_VALIDATED");
    append("PREFLIGHT_READY");
    append("EXECUTION_STARTED");
    append("VERIFICATION_STARTED", { verificationCycle: 1 });
    append("OBSERVATION", {
      executionId: "exec-portable",
      status: "started",
      evidenceRefs: ["z-ref", "a-ref"],
      hypotheses: [{ evidenceRefs: ["m-ref"] }],
    });
    append("OBSERVATION", { executionRef: "exec-portable", status: "finished", evidenceRefs: ["a-ref", "b-ref"] });
    append("CONTINUITY_RECORDED", { note: "portable checkpoint" });
    append("TASK_RECOVERY_RECORDED", {
      recoveryId: "recovery-parity",
      classification: "STALE",
      previousPhase: "VERIFYING",
      previousRevision: 0,
      authorityKind: "HOST_ATTESTED",
      reasonCodes: ["STALE_STATE"],
      releasedClaims: [],
    });
    append("VERIFICATION_RECORDED", {
      id: "portable-check",
      requirement: "portable",
      status: "failed",
      exitCode: 1,
      provenance: "FORGELOOP_EXECUTED",
      verificationCycle: 1,
    });
    append("COMPLETION_REJECTED", {
      verificationCycle: 1,
      reasonCodes: ["E_EVIDENCE_REQUIRED"],
      missingRequirementIds: ["REQ_MISSING"],
    });
    const actionFingerprint = "c".repeat(64);
    append("ACTION_PROPOSED", { actionId: "action-portable", actionFingerprint });
    append("ACTION_RECONCILED", { actionId: "action-portable", actionFingerprint, outcome: "UNKNOWN" });
    const duplicate = buildProtocolEvent({
      taskId,
      event: "OBSERVATION",
      details: { executionRef: "exec-portable", evidenceRefs: ["duplicate-ref"] },
    }, { checkpoint: { seq: events.length, lastHash } });
    duplicate.seq -= 1;
    events.push(duplicate);
    await writeFile(path.join(target, ".forgeloop/events.ndjson"), `${events.map(event => JSON.stringify(event)).join("\n")}\n`);

    // This branch invokes the private projection with an explicit array
    // snapshot. It verifies portable duplicate-sequence compatibility only;
    // storage admission and the owned audit are intentionally bypassed.
    const snapshot = {
      consistent: true,
      taskId: null,
      anchors: { stateRevision: state.revision, sequence: events.at(-1).seq, hash: events.at(-1).hash },
      capturedAt: "2026-10-10T00:00:00.000Z",
      integrity: {
        valid: false,
        errors: [{ code: "E_PARITY_DUPLICATE_SEQUENCE", message: "duplicate sequence control" }],
        eventCount: events.length,
        fingerprint: "d".repeat(64),
      },
      state,
      events,
    };
    const oldTrace = await buildOldTraceFromSnapshot({
      target,
      packageRoot: oldPackageRoot,
      taskId: null,
      eventsPath: ".forgeloop/events.ndjson",
      snapshot,
      eventProjection: null,
    });
    const currentTrace = await buildCurrentTraceFromSnapshot({
      target,
      packageRoot: currentPackageRoot,
      taskId: null,
      eventsPath: ".forgeloop/events.ndjson",
      snapshot,
      eventProjection: null,
    });
    assert.deepEqual(comparable(currentTrace), comparable(oldTrace));
    const trace = currentTrace;
    assert.equal(trace.task.present, true);
    assert.deepEqual(trace.executions.map(({ executionId }) => executionId), ["exec-portable"]);
    assert.deepEqual(trace.evidence.map(({ ref }) => ref), ["a-ref", "b-ref", "duplicate-ref", "m-ref", "z-ref"]);
    assert.equal(trace.completion.rejectedAt !== null, true);
    assert.deepEqual(trace.continuity.map(({ type }) => type), ["CONTINUITY_RECORDED"]);
    assert.equal(trace.recovery.length, 1);
    assert.equal(trace.actions.eventCount, 2);
    assert.equal(trace.integrity.valid, false);
    return { mode: "portable", totalEventCount: trace.events.length, integrityValid: trace.integrity.valid };
  } finally {
    await rm(target, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 });
  }
}

const results = [await nativeControl(), await portableControl()];
console.log(JSON.stringify({
  sourceRevision: "1d0b9698a50c8c5f84d593609e31dbf1c6586035",
  portableProjectionOnly: true,
  portableAuditBypassed: true,
  results,
}));
