/** External accepted full-audit fixture candidate; canonical commands, no SQL. */
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
import { rm } from 'node:fs/promises';
const load = (root, name) => import(pathToFileURL(path.join(root, name)).href);
export async function buildAcceptedPublicAuditFixture({ target, packageRoot, taskId, eventCount = null, calibratedPrelude = null }) {
  if (eventCount !== null && calibratedPrelude === null) {
    const { createGitRepository } = await load(packageRoot, 'tests/helpers/git-fixture.js');
    const calibration = await createGitRepository('forgeloop-accepted-audit-calibration-');
    let firstCause = null;
    try {
      const probe = await buildAcceptedPublicAuditFixture({ target: calibration, packageRoot, taskId });
      calibratedPrelude = probe.eventCount;
    } catch (error) { firstCause = error; }
    try { await rm(calibration, { recursive: true, force: true }); }
    catch (error) { if (!firstCause) firstCause = error; else firstCause.calibrationCleanupError = error.message; }
    if (firstCause) throw firstCause;
  }
  if (eventCount !== null) {
    assert.ok(Number.isInteger(eventCount) && eventCount >= calibratedPrelude, `requested accepted total ${eventCount} is below observed canonical prelude ${calibratedPrelude}`);
  }
  const { setupVerifyingTask } = await load(packageRoot, 'tests/helpers/durable-lifecycle.js');
  const { runCheck } = await load(packageRoot, 'src/commands/run-check.js');
  const { runAdvance } = await load(packageRoot, 'src/commands/advance.js');
  const { runComplete } = await load(packageRoot, 'src/commands/complete.js');
  const { runAudit } = await load(packageRoot, 'src/commands/audit.js');
  const { validateEventLedger, validateStateLedgerCoherence } = await load(packageRoot, 'src/core/events.js');
  const { readWorkState } = await load(packageRoot, 'src/core/work-state.js');
  // This mirrors the existing attestation-e2e completion prerequisites without
  // enabling signing or fabricating external signer evidence.
  await setupVerifyingTask(target, packageRoot, { taskId, requirement: 'tests' });
  for (const [id, requirement] of [['accepted-audit-test', 'tests'], ['accepted-audit-success', 'required action satisfies tests']]) {
    const check = await runCheck({ target, packageRoot, taskId, id, requirement, argv: [process.execPath, '-e', 'process.exit(0)'] });
    assert.equal(check.check.status, 'passed');
  }
  const beforeClosure = await validateEventLedger(target, packageRoot, { taskId });
  assert.equal(beforeClosure.valid, true);
  if (eventCount !== null && eventCount > calibratedPrelude) {
    const { appendCanonicalObservationEvents } = await load(packageRoot, 'scripts/lib/benchmark-domain-fixture.mjs');
    await appendCanonicalObservationEvents({ target, packageRoot, taskId, eventCount: beforeClosure.events.length + eventCount - calibratedPrelude, expectedInitialEventCount: beforeClosure.events.length });
  }
  await runAdvance({ target, packageRoot, taskId, to: 'REVIEWING' });
  const completion = await runComplete({ target, packageRoot, taskId });
  assert.equal(completion.status, 'VALID');
  const audit = await runAudit({ target, packageRoot, taskId });
  assert.equal(audit.status, 'VALID');
  const ledger = await validateEventLedger(target, packageRoot, { taskId });
  assert.equal(ledger.valid, true);
  if (eventCount !== null) assert.equal(ledger.events.length, eventCount, 'accepted public fixture event total drifted from the calibrated lifecycle');
  const state = await readWorkState(target, { packageRoot, taskId });
  assert.deepEqual(validateStateLedgerCoherence(state, ledger.events), []);
  return { taskId, status: 'ACCEPTED_PUBLIC_FULL_AUDIT', eventCount: ledger.events.length, audit, completion, phase: state.phase };
}
