/** Supported exported storage API fixture; no SQL setup and no fabricated signer. */
import assert from 'node:assert/strict';
import { Readable } from 'node:stream';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
export async function seedPublicExportAttachments({ target, packageRoot, taskId, db }) {
  const { registerAttachment, iterateAttachmentReferences } = await import(pathToFileURL(path.join(packageRoot, 'src/storage/index.js')).href);
  assert.equal(typeof registerAttachment, 'function');
  const entries = [
    { referenceId: 'benchmark-export-text-v1', bytes: Buffer.from('Canonical public export attachment.\n', 'utf8') },
    { referenceId: 'benchmark-export-binary-v1', bytes: Buffer.from([0, 255, 128, 13, 10, 0, 127, 254, 1, 2]) },
  ];
  const references = [];
  for (const entry of entries) {
    const reference = await registerAttachment(db, target, { taskId, referenceId: entry.referenceId, readable: Readable.from([entry.bytes]) });
    assert.equal(reference.size, entry.bytes.length);
    assert.equal(reference.sha256, createHash('sha256').update(entry.bytes).digest('hex'));
    references.push(reference);
  }
  const actual = [...iterateAttachmentReferences(db)].filter(reference => reference.taskId === taskId);
  for (const expected of references) assert.deepEqual(actual.find(reference => reference.referenceId === expected.referenceId), expected);
  return { kind: 'PUBLIC_STORAGE_ATTACHMENT_API', references, binaryReferenceId: entries[1].referenceId, attachmentCount: references.length, attestationClaim: false, protocolRunCheckAttachmentClaim: false };
}
