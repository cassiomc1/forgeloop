/** Human/reviewable project inputs remain files; copy unchanged for backend parity. */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { lstat, readFile, mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
export async function copyPublicBenchmarkProjectInputs({ nativeRoot, portableRoot, packageRoot }) {
  const { PROJECT_ARTIFACT_PATHS } = await import(pathToFileURL(path.join(packageRoot, 'src/core/task-paths.js')).href);
  const inputs = ['config', 'sources', 'policyRules', 'policyBaseline', 'policyLock', 'policyDiscovery', 'capabilityPolicy'];
  const files = [];
  for (const name of inputs) {
    const relative = PROJECT_ARTIFACT_PATHS[name];
    assert.ok(typeof relative === 'string' && relative.startsWith('.forgeloop/') && !relative.split('/').includes('..'));
    const source = path.join(nativeRoot, relative);
    const destination = path.join(portableRoot, relative);
    let sourceStat;
    try { sourceStat = await lstat(source); }
    catch (error) {
      if (error.code !== 'ENOENT') throw error;
      await assert.rejects(lstat(destination), { code: 'ENOENT' });
      files.push({ path: relative, present: false });
      continue;
    }
    assert.ok(sourceStat.isFile() && !sourceStat.isSymbolicLink(), `project input must be a regular file: ${relative}`);
    const bytes = await readFile(source);
    await mkdir(path.dirname(destination), { recursive: true });
    try { await writeFile(destination, bytes, { flag: 'wx' }); }
    catch (error) { if (error.code !== 'EEXIST') throw error; }
    assert.deepEqual(await readFile(destination), bytes, `portable project input differs: ${relative}`);
    files.push({ path: relative, present: true, size: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') });
  }
  return { status: 'EXACT_PROJECT_INPUT_BYTES', measured: false, files };
}
