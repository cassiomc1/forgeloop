/** External candidate; syntax checked only. Public warm API audit/bundle comparison. */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, mkdtemp, mkdir, rm, rename, cp } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { performance } from 'node:perf_hooks';
import { copyPublicBenchmarkProjectInputs } from './public-benchmark-project-inputs-819cd7a.mjs';
import { createMatchedPathFixture } from './public-benchmark-matched-path-819cd7a.mjs';
import { buildAcceptedPublicAuditFixture } from './public-valid-audit-fixture-819cd7a.mjs';
import { seedPublicExportAttachments } from './public-audit-export-attachment-fixture-819cd7a.mjs';
const arg = name => process.argv.find(x => x.startsWith(`--${name}=`))?.slice(name.length + 3);
const currentRoot = path.resolve(arg('current-root') ?? '/Users/cassio/.codex/worktrees/sqlite-end-to-end/forgeloop');
const baselineRoot = arg('baseline-root') ? path.resolve(arg('baseline-root')) : null;
const expectedCurrentRevision = arg('expected-current-revision') ?? 'b531ae184dcdefab035a52ece014a6e601e518e7';
const selectedFixture = arg('selected-fixture') ?? 'rich-recovering';
const validationOnly = process.argv.includes('--validate-only');
const sizes = (arg('sizes') ?? '10,100,250,1000,5000').split(',').map(Number);
const events = Number(arg('events') ?? 10);
const selectedEvents = Number(arg('selected-events') ?? 1000);
const repeats = Number(arg('repeats') ?? 20);
const warmup = Number(arg('warmup') ?? 0);
const importAt = (root, file) => import(pathToFileURL(path.join(root, file)).href);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const { captureBenchmarkSourceManifest } = await importAt(currentRoot, 'scripts/lib/benchmark-source-manifest.mjs');
const pairManifest = async () => ({ schemaVersion: 2, current: await captureBenchmarkSourceManifest(currentRoot), baseline: await captureBenchmarkSourceManifest(baselineRoot) });
const serialize = e => ({ name: e?.name ?? 'Error', code: e?.code ?? null, message: e?.message ?? String(e), stack: e?.stack ?? null, swapRollbackError: e?.swapRollbackError ?? null, fixtureRestoreError: e?.fixtureRestoreError ?? null, fixtureRepositoryCleanupError: e?.fixtureRepositoryCleanupError ?? null, calibrationCleanupError: e?.calibrationCleanupError ?? null });
function knownLedgerRefusal(value) {
  if (value?.valid !== false || value.errors?.length !== 1) return null;
  const e = value.errors[0];
  const artifact = e.artifacts?.[0];
  if (e.code !== 'JSON_LIMIT_EXCEEDED' || e.artifacts.length !== 1 || !/^\.forgeloop\/task-state\/[a-f0-9]{64}\/events\.ndjson$/.test(artifact) || e.message !== `${artifact} exceeds the 2097152-byte limit`) return null;
  return { code: e.code, message: e.message, artifacts: e.artifacts, baselineLimitBytes: 2097152 };
}
const report = { kind: 'PUBLIC_AUDIT_BUNDLE_PAIRED', status: 'PREPARING', selectedFixture, releaseThresholds: false, validationOnly, runtime: process.version, platform: process.platform, arch: process.arch, repeats, warmup, sizes, events, selectedEvents, fixtureSeed: 'public-rich-v1', mode: 'WARM_PUBLIC_API', filesystemCold: false, sourceBefore: null, sourceAfter: null, firstCause: null, cleanupErrors: [], results: [], limitations: ['Bundle comparison covers the common public task bundle contract; current schema 2 file bindings are validated independently, baseline schema 1 has no byte bindings.', 'Approvals are fixture-parity checked but neither public bundle exports approvals.', 'Two real public storage API attachments including binary bytes are seeded; these are not fabricated attestation or run-check attachments.', 'No cold CLI, resource budget, full-project export performance, or release acceptance claim.'] };
let temporary = null;
let activeSwap = null;
let stage = 'ARGUMENT_ADMISSION';
try {
  assert.ok(['rich-recovering', 'completed-accepted'].includes(selectedFixture));
  assert.ok(baselineRoot, '--baseline-root must explicitly select a clean pinned baseline checkout');
  assert.ok(sizes.length > 0 && sizes.every(n => Number.isInteger(n) && n >= 1 && n <= 5000));
  assert.ok(Number.isInteger(events) && events >= 2 && Number.isInteger(selectedEvents) && selectedEvents >= 2);
  assert.ok(Number.isInteger(repeats) && repeats >= 2 && repeats <= 100);
  assert.ok(Number.isInteger(warmup) && warmup >= 0 && warmup <= 100);
  stage = 'SOURCE_ADMISSION';
  report.sourceBefore = await pairManifest();
  assert.equal(report.sourceBefore.current.revision, expectedCurrentRevision, 'current source revision differs from the prepared external candidate');
  assert.equal(report.sourceBefore.baseline.revision, 'ee9ce11123d4e728d3dbc92f5d62d4bf41bb79c5');
  for (const source of [report.sourceBefore.current, report.sourceBefore.baseline]) assert.deepEqual(source.untrackedEvidence.unexpectedPaths, []);
  assert.equal(report.sourceBefore.baseline.status, '');
  if (!validationOnly) assert.equal(report.sourceBefore.current.status, '');
  const fixture = await importAt(currentRoot, 'scripts/lib/benchmark-domain-fixture.mjs');
  const storage = await importAt(currentRoot, 'src/storage/index.js');
  const currentEvents = await importAt(currentRoot, 'src/core/events.js');
  const baselineEvents = await importAt(baselineRoot, 'src/core/events.js');
  const currentState = await importAt(currentRoot, 'src/core/work-state.js');
  const baselineState = await importAt(baselineRoot, 'src/core/work-state.js');
  const api = {};
  for (const [backend, root] of Object.entries({ current: currentRoot, baseline: baselineRoot })) api[backend] = { audit: (await importAt(root, 'src/commands/audit.js')).runAudit, bundle: (await importAt(root, 'src/commands/bundle.js')).runBundle, read: (await importAt(root, 'src/core/bundles.js')).readTaskBundle };
  for (const size of sizes) {
    stage = 'FIXTURE';
    temporary = await mkdtemp(path.join(os.tmpdir(), 'forgeloop-public-audit-bundle-'));
    const native = path.join(temporary, 'native');
    const portable = path.join(temporary, 'portable');
    await mkdir(native);
    await mkdir(portable);
    const idAt = i => `public-audit-${String(i).padStart(5, '0')}`;
    const taskId = idAt(0);
    let selectedProof;
    if (selectedFixture === 'completed-accepted') {
      const { createGitRepository } = await importAt(currentRoot, 'tests/helpers/git-fixture.js');
      const repository = await createGitRepository('forgeloop-accepted-audit-source-');
      try {
        await rm(native, { recursive: true, force: true });
        await rename(repository, native);
      } catch (error) { try { await rm(repository, { recursive: true, force: true }); } catch (cleanupError) { error.fixtureRepositoryCleanupError = cleanupError.message; } throw error; }
      selectedProof = await buildAcceptedPublicAuditFixture({ target: native, packageRoot: currentRoot, taskId, eventCount: selectedEvents });
    } else {
      const rich = await fixture.buildRichSelectedTaskFixture({ target: native, packageRoot: currentRoot, taskId, claims: ['src/public-audit-selected'] });
      await fixture.appendCanonicalObservationEvents({ target: native, packageRoot: currentRoot, taskId, eventCount: selectedEvents, expectedInitialEventCount: rich.ledger.length });
      selectedProof = { status: 'RICH_RECOVERING', expectedAuditValid: false };
    }
    const ordinary = await fixture.buildPublicTaskDataset({ target: native, packageRoot: currentRoot, size, startIndex: 1, taskIdAt: idAt, eventCount: events });
    const db = storage.openStorageDatabase(path.join(native, '.forgeloop/state.sqlite'));
    let exported;
    let attachmentFixture;
    try {
      attachmentFixture = await seedPublicExportAttachments({ target: native, packageRoot: currentRoot, taskId, db });
      exported = await storage.exportDatabase(db, portable, { attachmentRoot: native });
    } finally { db.close(); }
    if (selectedFixture === 'completed-accepted') {
      // Audit repository/receipt observations must see the identical committed
      // fixture repository on both backends; this is unmeasured setup only.
      await cp(path.join(native, '.git'), path.join(portable, '.git'), { recursive: true });
      await cp(path.join(native, 'src'), path.join(portable, 'src'), { recursive: true });
    }
    const projectInputParity = await copyPublicBenchmarkProjectInputs({ nativeRoot: native, portableRoot: portable, packageRoot: currentRoot });
    assert.equal(attachmentFixture.attachmentCount, 2);
    for (const expected of attachmentFixture.references) assert.deepEqual(exported.index.attachments.find(reference => reference.taskId === expected.taskId && reference.referenceId === expected.referenceId), expected);
    assert.equal(exported.tasks, size);
    assert.equal(exported.index.tasks.length, size);
    for (const task of exported.index.tasks) {
      const directory = path.join(portable, '.forgeloop/task-state', task.taskKey);
      const projection = JSON.parse(await readFile(path.join(directory, 'export-manifest.json'), 'utf8'));
      assert.equal(projection.taskId, task.taskId);
      assert.equal(projection.events, task.taskId === taskId ? selectedEvents : events);
      assert.deepEqual(projection.included, projection.files.map(file => file.path).sort());
      if (task.taskId === taskId && selectedFixture === 'rich-recovering') {
        assert.ok(projection.included.some(file => file.startsWith('approvals/')), 'full-project setup export must retain the real approval');
        assert.ok(projection.included.some(file => file.startsWith('actions/')), 'full-project setup export must retain the real action');
      }
      for (const file of projection.files) {
        assert.ok(!path.isAbsolute(file.path) && !file.path.split(/[\\/]/).includes('..'));
        const bytes = await readFile(path.join(directory, file.path));
        assert.equal(bytes.length, file.size);
        assert.equal(hash(bytes), file.sha256);
      }
    }
    for (const reference of exported.index.attachments) {
      const a = await readFile(path.join(native, reference.path));
      const b = await readFile(path.join(portable, reference.path));
      assert.deepEqual(a, b);
      assert.equal(a.length, reference.size);
      assert.equal(hash(a), reference.sha256);
    }
    stage = 'PARITY_ADMISSION';
    let refusal = null;
    for (const id of [taskId, ...ordinary]) {
      const a = await currentEvents.validateEventLedger(native, currentRoot, { taskId: id });
      const b = await baselineEvents.validateEventLedger(portable, baselineRoot, { taskId: id });
      assert.equal(a.valid, true);
      refusal = knownLedgerRefusal(b);
      if (refusal) break;
      assert.equal(b.valid, true);
      assert.equal(a.events.length, id === taskId ? selectedEvents : events);
      assert.deepEqual(b.events, a.events);
      for (const [root, packageRoot, module, stateModule] of [[native, currentRoot, currentEvents, currentState], [portable, baselineRoot, baselineEvents, baselineState]]) assert.deepEqual(module.validateStateLedgerCoherence(await stateModule.readWorkState(root, { packageRoot, taskId: id }), a.events), []);
    }
    if (refusal) {
      report.results.push({ size, status: 'BASELINE_LEDGER_REFUSAL', refusal, comparable: false, operations: { audit: null, bundle: null }, timing: null, samples: 0 });
    } else {
      const parity = await fixture.validateRichFixtureAcrossBackends({ nativeRoot: native, portableRoot: portable, currentRoot, baselineRoot, taskId, taskIds: ordinary });
      const roots = { current: native, baseline: native };
      const { getOperationalStore } = await importAt(currentRoot, 'src/storage/operational-context.js');
      activeSwap = createMatchedPathFixture({ target: native, portable, holding: temporary, assertClosed: async () => {
        assert.throws(() => db.prepare('SELECT 1'), 'setup database must close before path swaps');
        assert.equal(getOperationalStore(native), null, 'no operational context may remain live before path swaps');
      } });
      const packageRoots = { current: currentRoot, baseline: baselineRoot };
      const samples = { audit: { current: [], baseline: [] }, bundle: { current: [], baseline: [] } };
      let bundleProof = null;
      async function checkBundle(outputs) {
        assert.equal(outputs.current.schemaVersion, 2);
        assert.equal(outputs.baseline.schemaVersion, 1);
        const common = output => ({ protocolVersion: output.protocolVersion, taskId: output.taskId, artifacts: output.artifacts, path: output.path });
        assert.deepEqual(common(outputs.current), common(outputs.baseline));
        assert.equal(outputs.current.files.length, outputs.current.artifacts.length);
        const bindings = new Map(outputs.current.files.map(f => [f.path, f]));
        assert.equal(bindings.size, outputs.current.artifacts.length);
        let bytes = 0;
        for (const file of outputs.current.artifacts) {
          assert.ok(!path.isAbsolute(file) && !file.split(/[\\/]/).some(part => part === '..'));
          const a = await readFile(path.join(native, path.dirname(outputs.current.path), file));
          const b = await readFile(path.join(portable, path.dirname(outputs.baseline.path), file));
          assert.deepEqual(a, b, `exported artifact differs: ${file}`);
          assert.equal(bindings.get(file)?.size, a.length);
          assert.equal(bindings.get(file)?.sha256, hash(a));
          bytes += a.length;
        }
        await activeSwap.withBackend('current', target => api.current.read(target, taskId, currentRoot));
        await activeSwap.withBackend('baseline', target => api.baseline.read(target, taskId, baselineRoot));
        return { currentSchemaVersion: 2, baselineSchemaVersion: 1, commonArtifactsEqual: true, artifacts: outputs.current.artifacts.length, bytes, currentByteBindingsValidated: true, baselineByteBindingsAvailable: false, approvalsExported: false, setupAttachments: exported.index.attachments.length, attachmentFixture };
      }
      stage = 'PUBLIC_OPERATIONS';
      const rounds = validationOnly ? 1 : warmup + repeats;
      for (let round = 0; round < rounds; round++) for (const operation of ['audit', 'bundle']) {
        const outputs = {};
        for (const backend of round % 2 ? ['baseline', 'current'] : ['current', 'baseline']) {
          const measured = await activeSwap.withBackend(backend, async target => {
            assert.equal(target, roots[backend]);
            const start = performance.now();
            const output = await api[backend][operation]({ target, packageRoot: packageRoots[backend], taskId });
            return { output, duration: performance.now() - start };
          });
          outputs[backend] = measured.output;
          const duration = measured.duration;
          if (!validationOnly && round >= warmup) { assert.ok(Number.isFinite(duration) && duration >= 0); samples[operation][backend].push(duration); }
        }
        if (operation === 'audit') {
          assert.deepEqual(outputs.current, outputs.baseline, 'full public audit results differ');
          if (selectedFixture === 'completed-accepted') assert.equal(outputs.current.status, 'VALID');
          else assert.notEqual(outputs.current.status, 'VALID', 'recovering diagnosis fixture cannot claim accepted-audit coverage');
        }
        else bundleProof = await checkBundle(outputs);
      }
      const summaries = {};
      for (const [operation, backends] of Object.entries(samples)) {
        summaries[operation] = {};
        for (const [backend, values] of Object.entries(backends)) {
          assert.equal(values.length, validationOnly ? 0 : repeats);
          const sorted = [...values].sort((a, b) => a - b);
          summaries[operation][backend] = { count: values.length, samplesMs: values, p50Ms: validationOnly ? null : sorted[Math.ceil(sorted.length * .5) - 1], p95Ms: validationOnly ? null : sorted[Math.ceil(sorted.length * .95) - 1], throughputPerSecond: validationOnly ? null : values.length * 1000 / values.reduce((a, b) => a + b, 0) };
        }
      }
      report.results.push({ size, status: validationOnly ? 'VALIDATED_NO_TIMING' : 'MEASURED_COMMON_PUBLIC_CONTRACT', parity, projectInputParity, selectedProof, taskCount: size, totalEvents: selectedEvents + (size - 1) * events, bundleProof, operations: summaries, fullRequestedCoverage: false });
    }
    stage = 'CLEANUP';
    if (activeSwap) { await activeSwap.restore(); activeSwap = null; }
    await rm(temporary, { recursive: true, force: true });
    temporary = null;
  }
  report.status = validationOnly ? 'VALIDATED_NO_TIMING' : 'MEASURED_COMMON_PUBLIC_CONTRACT';
} catch (error) {
  report.firstCause = { stage, ...serialize(error) };
  report.status = 'FAILED';
} finally {
  if (activeSwap) try { await activeSwap.restore(); } catch (error) { report.cleanupErrors.push(serialize(error)); }
  if (temporary) try { await rm(temporary, { recursive: true, force: true }); } catch (error) { report.cleanupErrors.push(serialize(error)); }
  try {
    if (baselineRoot) report.sourceAfter = await pairManifest();
    if (report.sourceBefore) assert.deepEqual(report.sourceAfter, report.sourceBefore, 'source changed during paired run');
  } catch (error) {
    if (!report.firstCause) report.firstCause = { stage: 'SOURCE_AFTER', ...serialize(error) };
    else report.sourceAfterError = serialize(error);
    report.status = 'FAILED';
  }
  if (report.cleanupErrors.length) report.status = 'FAILED';
  if (report.status === 'FAILED') for (const result of report.results) result.operations = null;
}
console.log(JSON.stringify(report, null, 2));
if (report.status === 'FAILED') process.exitCode = 1;
