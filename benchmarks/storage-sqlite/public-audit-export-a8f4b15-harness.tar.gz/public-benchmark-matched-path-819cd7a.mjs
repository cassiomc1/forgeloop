/** Swap disposable closed fixture directories; never rewrite execution receipts. */
import assert from 'node:assert/strict';
import { rename } from 'node:fs/promises';
import path from 'node:path';
export function createMatchedPathFixture({ target, portable, holding, assertClosed = async () => {} }) {
  const parkedNative = path.join(holding, 'parked-native');
  let baselineActive = false;
  let callbackActive = false;
  async function select(baseline) {
    assert.equal(callbackActive, false, 'fixture swap cannot overlap a public operation');
    if (baseline === baselineActive) return;
    await assertClosed();
    const parked = baseline ? parkedNative : portable;
    const incoming = baseline ? portable : parkedNative;
    await rename(target, parked);
    try { await rename(incoming, target); }
    catch (error) {
      try { await rename(parked, target); }
      catch (rollbackError) { error.swapRollbackError = { code: rollbackError.code ?? null, message: rollbackError.message }; }
      throw error;
    }
    baselineActive = baseline;
  }
  return {
    async withBackend(backend, callback) {
      assert.ok(['current', 'baseline'].includes(backend));
      await select(backend === 'baseline');
      callbackActive = true;
      let value;
      let firstCause = null;
      try { value = await callback(target); }
      catch (error) { firstCause = error; }
      finally { callbackActive = false; }
      try { await select(false); }
      catch (error) {
        if (!firstCause) firstCause = error;
        else firstCause.fixtureRestoreError = { code: error.code ?? null, message: error.message };
      }
      if (firstCause) throw firstCause;
      return value;
    },
    async restore() { await select(false); },
    state() { return { baselineActive, callbackActive }; },
  };
}
