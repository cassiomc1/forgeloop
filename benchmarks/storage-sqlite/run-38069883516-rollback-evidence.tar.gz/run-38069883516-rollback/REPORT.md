# Hosted public rollback evidence
Run https://github.com/cassiomc1/forgeloop/actions/runs/38069883516 succeeded at expected head 000503459f7344b7edb62bd3c1eccd9f8533b07c.
Read-only artifact/log review. No repository edits or workloads.

## Linux
Job 114264964223; linux/x64; Node v24.19.0; 376.659s.
Evidence directory: /Users/cassio/.codex/verification/run-38069883516-rollback/artifacts/sqlite-public-rollback-Linux
| Case | Result |
| --- | --- |
| initial-false | exit 0, stdout SHA-256 matches terminal |
| initial-true | exit 0, stdout SHA-256 matches terminal |
| PREP_READY | exit 0, stdout SHA-256 matches terminal |
| PREP_PREPARING_COMPLETE | exit 0, stdout SHA-256 matches terminal |
| PREP_PREPARING_PARTIAL | exit 0, stdout SHA-256 matches terminal |
| PREP_PREPARING_MISSING | exit 0, stdout SHA-256 matches terminal |
| STAGE_READY | exit 0, stdout SHA-256 matches terminal |
| STAGE_PREPARING_COMPLETE | exit 0, stdout SHA-256 matches terminal |
| STAGE_PREPARING_PARTIAL | exit 0, stdout SHA-256 matches terminal |
| STAGE_PREPARING_MISSING | exit 0, stdout SHA-256 matches terminal |
| STAGE_PREPARING_BINARY | exit 0, stdout SHA-256 matches terminal |
| SWITCHING | exit 0, stdout SHA-256 matches terminal |
| DATABASE_RETAINED | exit 0, stdout SHA-256 matches terminal |
| NATIVE_RETAINED | exit 0, stdout SHA-256 matches terminal |
| PARTIAL_SOURCE | exit 0, stdout SHA-256 matches terminal |
| RESTORED | exit 0, stdout SHA-256 matches terminal |

All 14 recovery cases report before/after legacy VALID, source restored, native bytes unchanged, maintenance released, target validated. Six recovery cases preserve the 7-byte binary attachment reference. Initial pre-write publication reports VALID exact target 1.14.0 at ee9ce11123d4e728d3dbc92f5d62d4bf41bb79c5 and unchanged native snapshot. Post-write negative control refuses restoration and production admission, preserving the native task.

## Windows
Job 114264964306; win32/x64; Node v24.19.0; 489.075s.
Evidence directory: /Users/cassio/.codex/verification/run-38069883516-rollback/artifacts/sqlite-public-rollback-Windows
| Case | Result |
| --- | --- |
| initial-false | exit 0, stdout SHA-256 matches terminal |
| initial-true | exit 0, stdout SHA-256 matches terminal |
| PREP_READY | exit 0, stdout SHA-256 matches terminal |
| PREP_PREPARING_COMPLETE | exit 0, stdout SHA-256 matches terminal |
| PREP_PREPARING_PARTIAL | exit 0, stdout SHA-256 matches terminal |
| PREP_PREPARING_MISSING | exit 0, stdout SHA-256 matches terminal |
| STAGE_READY | exit 0, stdout SHA-256 matches terminal |
| STAGE_PREPARING_COMPLETE | exit 0, stdout SHA-256 matches terminal |
| STAGE_PREPARING_PARTIAL | exit 0, stdout SHA-256 matches terminal |
| STAGE_PREPARING_MISSING | exit 0, stdout SHA-256 matches terminal |
| STAGE_PREPARING_BINARY | exit 0, stdout SHA-256 matches terminal |
| SWITCHING | exit 0, stdout SHA-256 matches terminal |
| DATABASE_RETAINED | exit 0, stdout SHA-256 matches terminal |
| NATIVE_RETAINED | exit 0, stdout SHA-256 matches terminal |
| PARTIAL_SOURCE | exit 0, stdout SHA-256 matches terminal |
| RESTORED | exit 0, stdout SHA-256 matches terminal |

All 14 recovery cases report before/after legacy VALID, source restored, native bytes unchanged, maintenance released, target validated. Six recovery cases preserve the 7-byte binary attachment reference. Initial pre-write publication reports VALID exact target 1.14.0 at ee9ce11123d4e728d3dbc92f5d62d4bf41bb79c5 and unchanged native snapshot. Post-write negative control refuses restoration and production admission, preserving the native task.

## Manifests and cleanup
Each manifest has 3,414 unique tracked-file entries. Same path sets across platforms; 55 cross-platform byte digests differ (listed in cross-platform-manifest-differences.json). All 55 differences are independently attributable to exact-head Git blob LF/CRLF transformations; matching forms are listed in manifest-normalization-attribution.json. The retained exact-head aggregate source directly builds before/after manifests via git ls-files and SHA-256 of file bytes and compares their JSON before reporting admittedSourceUnchanged. Only the before manifest is retained, so independent re-comparison of after bytes is unavailable. Each terminal separately reports its admitted source unchanged after all drills.
Exact-head drill sources retained as drill-source.mjs, recovery-source.mjs, prewrite-source.mjs. Per-case scripts call fixture cleanup and retained-directory removal in finally blocks. Successful process exit supports those calls returning; GitHub post-job cleanup also succeeded. No separate post-cleanup filesystem inventory proves absence of every runner leftover.

## Limits
Constructed persisted owner-death checkpoints, not syscall power loss. Disposable linked worktrees, no live migration. No privileged/uninventoried writer exclusion. Timeout cleanup not exercised. Old-client exclusion steps, paired MCP resources and Windows full Node suite are skipped in this run; no claim for those gates, full regression, protocol completion, merge or publication.

Run metadata: /Users/cassio/.codex/verification/run-38069883516-rollback/run.json
Logs: /Users/cassio/.codex/verification/run-38069883516-rollback/run.log
