import { createHash } from "node:crypto";
import { execFileSync, spawnSync } from "node:child_process";
import {
  lstat,
  mkdtemp,
  readFile,
  readlink,
  realpath,
  readdir,
  rm,
  symlink,
  writeFile,
} from "node:fs/promises";
import os from "node:os";
import path from "node:path";

const worktree = "/Users/cassio/.codex/worktrees/sqlite-end-to-end/forgeloop";
const sourceRevision = "1d0b9698a50c8c5f84d593609e31dbf1c6586035";
const traceRelative = "src/core/trace.js";
const traceExport = "\nexport { buildTraceFromSnapshot };\n";
const harnessPath = "/Users/cassio/.codex/verification/trace-parity-control.mjs";
const receiptPath = "/Users/cassio/.codex/verification/trace-parity-control-prepared-1d0b969.json";
const logPath = "/Users/cassio/.codex/verification/trace-parity-control-prepared-1d0b969.log";

function sha256(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

function digestManifest(entries) {
  return sha256(Buffer.from(JSON.stringify(entries)));
}

function gitBytes(args) {
  return execFileSync("git", args, {
    cwd: worktree,
    maxBuffer: 512 * 1024 * 1024,
  });
}

async function listSourceFiles(root, relative = "", entries = []) {
  const directory = path.join(root, relative);
  const children = (await readdir(directory)).sort();
  for (const child of children) {
    const childRelative = relative ? path.join(relative, child) : child;
    if (childRelative === "node_modules" || childRelative.startsWith("node_modules/")) continue;
    const childPath = path.join(root, childRelative);
    const stats = await lstat(childPath);
    if (stats.isDirectory()) {
      await listSourceFiles(root, childRelative, entries);
      continue;
    }
    if (childRelative === traceRelative) continue;
    if (stats.isSymbolicLink()) {
      entries.push({ path: childRelative, kind: "symlink", target: await readlink(childPath) });
      continue;
    }
    if (!stats.isFile()) throw new Error(`Unsupported source entry: ${childRelative}`);
    entries.push({ path: childRelative, kind: "file", sha256: sha256(await readFile(childPath)) });
  }
  return entries;
}

async function sourceManifest(root) {
  const entries = await listSourceFiles(root);
  return {
    excluded: [traceRelative, "node_modules/**"],
    fileCount: entries.length,
    entries,
    sha256: digestManifest(entries),
  };
}

async function prepareCopy({ root, archive, traceBytes }) {
  execFileSync("tar", ["-xf", "-", "-C", root], {
    input: archive,
    maxBuffer: 512 * 1024 * 1024,
  });
  const tracePath = path.join(root, traceRelative);
  await writeFile(tracePath, Buffer.concat([traceBytes, Buffer.from(traceExport)]));
  const dependencyTarget = path.join(worktree, "node_modules");
  await symlink(dependencyTarget, path.join(root, "node_modules"), "dir");
  const linkTarget = await readlink(path.join(root, "node_modules"));
  const resolvedTarget = await realpath(path.join(root, "node_modules"));
  return {
    root,
    tracePath,
    traceSha256: sha256(await readFile(tracePath)),
    nodeModules: { linkTarget, resolvedTarget },
  };
}

function runHarness(oldRoot, currentRoot) {
  const environment = { ...process.env };
  delete environment.TYPESAFE_API_KEY;
  delete environment.NODE_OPTIONS;
  environment.TRACE_PARITY_OLD_ROOT = oldRoot;
  environment.TRACE_PARITY_CURRENT_ROOT = currentRoot;
  const result = spawnSync(process.execPath, [harnessPath], {
    cwd: worktree,
    env: environment,
    encoding: "utf8",
    maxBuffer: 32 * 1024 * 1024,
  });
  const stdout = result.stdout ?? "";
  const stderr = result.stderr ?? "";
  if (result.error) throw result.error;
  const log = `${stdout}${stderr}`;
  return {
    exitCode: result.status,
    signal: result.signal,
    stdout,
    stderr,
    log,
    parsed: result.status === 0 ? JSON.parse(stdout.trim()) : null,
  };
}

async function main() {
  const archive = gitBytes(["archive", "--format=tar", sourceRevision]);
  const frozenTrace = gitBytes(["show", `${sourceRevision}:${traceRelative}`]);
  const currentTrace = await readFile(path.join(worktree, traceRelative));
  const dependencyTarget = path.join(worktree, "node_modules");
  const dependencyResolvedTarget = await realpath(dependencyTarget);
  const receipt = {
    schemaVersion: 1,
    status: "RUNNING",
    startedAt: new Date().toISOString(),
    sourceRevision,
    worktree,
    traceRelative,
    harness: harnessPath,
    setupScript: "/Users/cassio/.codex/verification/prepare-trace-parity-control.mjs",
    log: logPath,
    receipt: receiptPath,
    source: {
      frozenTraceSha256: sha256(frozenTrace),
      currentDraftTraceSha256: sha256(currentTrace),
      archiveSha256: sha256(archive),
    },
    dependencies: {
      requestedTarget: dependencyTarget,
      resolvedTarget: dependencyResolvedTarget,
    },
    scope: "External parity preparation only; no tracked repository files are changed.",
  };
  let oldRoot = null;
  let currentRoot = null;
  let failure = null;
  try {
    oldRoot = await mkdtemp(path.join(os.tmpdir(), "forgeloop-trace-parity-old-"));
    currentRoot = await mkdtemp(path.join(os.tmpdir(), "forgeloop-trace-parity-current-"));
    const oldCopy = await prepareCopy({ root: oldRoot, archive, traceBytes: frozenTrace });
    const currentCopy = await prepareCopy({ root: currentRoot, archive, traceBytes: currentTrace });
    const oldManifest = await sourceManifest(oldRoot);
    const currentManifest = await sourceManifest(currentRoot);
    const manifestMismatches = [];
    if (oldManifest.sha256 !== currentManifest.sha256) manifestMismatches.push("manifest digest differs");
    if (oldManifest.fileCount !== currentManifest.fileCount) manifestMismatches.push("manifest entry count differs");
    if (JSON.stringify(oldManifest.entries) !== JSON.stringify(currentManifest.entries)) {
      manifestMismatches.push("manifest entries differ");
    }
    receipt.copies = {
      old: oldCopy,
      current: currentCopy,
      sourceManifest: {
        old: oldManifest,
        current: currentManifest,
        mismatches: manifestMismatches,
        equal: manifestMismatches.length === 0,
      },
    };
    receipt.dependencies.copies = {
      old: oldCopy.nodeModules,
      current: currentCopy.nodeModules,
      sameLinkTarget: oldCopy.nodeModules.linkTarget === currentCopy.nodeModules.linkTarget,
      sameResolvedTarget: oldCopy.nodeModules.resolvedTarget === currentCopy.nodeModules.resolvedTarget,
    };
    if (!receipt.copies.sourceManifest.equal) throw new Error(`Prepared source manifests differ: ${manifestMismatches.join(", ")}`);
    if (!receipt.dependencies.copies.sameLinkTarget || !receipt.dependencies.copies.sameResolvedTarget) {
      throw new Error("Prepared copies do not share the same dependency target");
    }
    const harness = runHarness(oldRoot, currentRoot);
    await writeFile(logPath, harness.log);
    receipt.harnessResult = {
      exitCode: harness.exitCode,
      signal: harness.signal,
      parsed: harness.parsed,
    };
    if (harness.exitCode !== 0) throw new Error(`Parity harness exited with ${harness.exitCode ?? harness.signal}`);
    receipt.portableControl = {
      projectionOnly: harness.parsed?.portableProjectionOnly === true,
      auditBypassed: harness.parsed?.portableAuditBypassed === true,
      reason: "The portable branch invokes the private projection with an explicit array snapshot; storage admission and the owned audit are bypassed.",
    };
    if (!receipt.portableControl.projectionOnly || !receipt.portableControl.auditBypassed) {
      throw new Error("Portable parity was not explicitly labeled projection-only with the audit bypassed");
    }
    receipt.status = "PASS";
  } catch (error) {
    failure = error;
    receipt.status = "FAIL";
    receipt.error = { name: error?.name, message: error?.message, stack: error?.stack };
  } finally {
    const cleanup = {};
    for (const [name, root] of [["oldRoot", oldRoot], ["currentRoot", currentRoot]]) {
      if (!root) {
        cleanup[name] = { path: null, removed: true };
        continue;
      }
      await rm(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 });
      let exists = true;
      try {
        await lstat(root);
      } catch (error) {
        if (error?.code === "ENOENT") exists = false;
        else throw error;
      }
      cleanup[name] = { path: root, removed: !exists };
    }
    receipt.cleanup = {
      ...cleanup,
      temporaryCopiesRemoved: Boolean(cleanup.oldRoot?.removed && cleanup.currentRoot?.removed),
    };
    receipt.finishedAt = new Date().toISOString();
    receipt.setupSha256 = sha256(await readFile("/Users/cassio/.codex/verification/prepare-trace-parity-control.mjs"));
    receipt.harnessSha256 = sha256(await readFile(harnessPath));
    await writeFile(receiptPath, `${JSON.stringify(receipt, null, 2)}\n`);
  }
  if (failure) throw failure;
  console.log(JSON.stringify({
    status: receipt.status,
    receipt: receiptPath,
    log: logPath,
    frozenTraceSha256: receipt.source.frozenTraceSha256,
    currentDraftTraceSha256: receipt.source.currentDraftTraceSha256,
    sourceManifestEqual: receipt.copies.sourceManifest.equal,
    dependenciesSame: receipt.dependencies.copies.sameLinkTarget && receipt.dependencies.copies.sameResolvedTarget,
    temporaryCopiesRemoved: receipt.cleanup.temporaryCopiesRemoved,
  }));
}

await main();
