import { registerHooks } from "node:module";
import { pathToFileURL } from "node:url";

const root = "/Users/cassio/.codex/worktrees/sqlite-end-to-end/forgeloop";
const runner = pathToFileURL(`${root}/scripts/benchmark-storage-idempotency.mjs`).href;
const storage = pathToFileURL(`${root}/src/storage/index.js`).href;
const injected = `export * from ${JSON.stringify(storage)};
export async function exportDatabase() {
  const error = new Error("Injected export failure for benchmark error-retention validation");
  error.code = "E_TEST_EXPORT_FAILURE";
  throw error;
}`;
registerHooks({
  resolve(specifier, context, nextResolve) {
    if (context.parentURL === runner && specifier === "../src/storage/index.js") {
      return { url: `data:text/javascript,${encodeURIComponent(injected)}`, shortCircuit: true };
    }
    return nextResolve(specifier, context);
  },
});
