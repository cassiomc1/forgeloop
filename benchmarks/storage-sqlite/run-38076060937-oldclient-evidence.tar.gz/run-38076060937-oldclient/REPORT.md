# Old-client exclusion evidence review
Run https://github.com/cassiomc1/forgeloop/actions/runs/38076060937: completed success at expected head 4dabc38946bbb3246deff1de8d1658c74e98abf9.
Read-only review; no worktree edits or local workloads.

## Linux
Job 114283140227 success. Evidence: /Users/cassio/.codex/verification/run-38076060937-oldclient/artifacts/sqlite-old-client-Linux
Node v24.19.0; pinned legacy ee9ce11123d4e728d3dbc92f5d62d4bf41bb79c5; strategy separate-data-owner.
Raw stdout parses as one JSON object. Before/after source manifests independently compare equal (3,455 files), expected revision unchanged. Parent exited 0 without signal/error/timeout. Cleanup PASS: no prefixed temporary entries before/after, no reported leaks, direct child terminated.
Migration without quiescence refused; actual legacy lock busy refused; old client attempts after stop/cutover exit 1. Native migration PUBLISHED with 2 tasks, subsequent native write PUBLISHED with 3 tasks; backup preserved and old layout absent.
Platform refusal evidence: {"directPermissionRefusal": true}

## Windows
Job 114283140338 success. Evidence: /Users/cassio/.codex/verification/run-38076060937-oldclient/artifacts/sqlite-old-client-Windows
Node v24.19.0; pinned legacy ee9ce11123d4e728d3dbc92f5d62d4bf41bb79c5; strategy disabled-legacy-installation.
Raw stdout parses as one JSON object. Before/after source manifests independently compare equal (3,455 files), expected revision unchanged. Parent exited 0 without signal/error/timeout. Cleanup PASS: no prefixed temporary entries before/after, no reported leaks, direct child terminated.
Migration without quiescence refused; actual legacy lock busy refused; old client attempts after stop/cutover exit 1. Native migration PUBLISHED with 2 tasks, subsequent native write PUBLISHED with 3 tasks; backup preserved and old layout absent.
Platform refusal evidence: {"deniedRead": "EPERM", "sourceIdentityVerification": "after-fixture-acl-restoration", "maskedMainEntrypoint": true}

## Limits
Cleanup does not measure descendant process reaping or runner-wide quiescence. Exclusion proves only inventoried fixture identity/installation; privileged permission changes and other installations remain outside proof. Windows uses disabled legacy installation with deniedRead EPERM and masked main entrypoint; source identity verified after fixture ACL restoration. Linux uses separate data owner and direct permission refusal. No full-suite claim: job named Windows full Node suite was selected with setup-only suite. Paired MCP job skipped. No live migration, protocol closure, merge or publication established.
Run metadata: /Users/cassio/.codex/verification/run-38076060937-oldclient/run.json
Logs: /Users/cassio/.codex/verification/run-38076060937-oldclient/linux.log and /Users/cassio/.codex/verification/run-38076060937-oldclient/windows.log
