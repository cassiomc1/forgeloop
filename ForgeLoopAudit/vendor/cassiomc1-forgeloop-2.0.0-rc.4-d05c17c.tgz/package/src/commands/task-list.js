import { discoverTaskListPage } from "../core/task-discovery.js";
import { WORK_PHASES } from "../core/protocol.js";

export async function runTaskList({ target, packageRoot, phase = null, active = false, limit = null, offset = 0 } = {}) {
  const normalizedPhase = typeof phase === "string" && phase.trim() !== "" ? phase.trim().toUpperCase() : null;
  const start = Number.isInteger(offset) && offset >= 0 ? offset : 0;
  const pageLimit = Number.isInteger(limit) && limit >= 0 ? limit : null;
  const { tasks: projected, total } = await discoverTaskListPage(target, packageRoot, { phase: normalizedPhase, active, offset: start, limit: pageLimit });
  if (normalizedPhase && !WORK_PHASES.includes(normalizedPhase)) {
    const error = new Error(`Unknown task phase filter: ${phase}`);
    error.code = "E_TASK_PHASE_INVALID";
    throw error;
  }
  const end = pageLimit === null ? undefined : start + pageLimit;
  return {
    tasks: projected,
    ...(normalizedPhase ? { phase: normalizedPhase } : {}),
    ...(active ? { active: true } : {}),
    offset: start,
    ...(Number.isInteger(limit) && limit >= 0 ? { limit } : {}),
    total,
    hasMore: end !== undefined ? end < total : false,
  };
}

export function formatTaskListResult(result) {
  if (result.tasks.length === 0) {
    return "no tasks found\n";
  }
  const lines = ["Tasks:"];
  for (const task of result.tasks) {
    if (task.healthy === false) {
      lines.push(`- ${task.taskKey} [CORRUPT]: ${task.error?.message ?? "unhealthy task namespace"}`);
    } else {
      const lockStr = task.locked ? " [LOCKED]" : "";
      const recoveryStr = task.claimState === "RELEASED_BY_RECOVERY"
        ? " [RECOVERED]"
        : task.claimState === "INCONSISTENT"
          ? " [OWNERSHIP INCONSISTENT]"
          : "";
      const claimsStr = task.writeClaims.length > 0 ? ` (claims: ${task.writeClaims.join(", ")})` : "";
      lines.push(`- ${task.taskId}: ${task.phase ?? "UNINITIALIZED"}${lockStr}${recoveryStr}${claimsStr}`);
    }
  }
  return `${lines.join("\n")}\n`;
}
